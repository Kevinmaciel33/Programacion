#include<banco.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>
