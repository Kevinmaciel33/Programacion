#ifndef CLASEB_H
#define CLASEB_H

#include "Clases.h"

class ClaseB : public Clases
{
    private:
        int valor1;

    public:
        ClaseB(int valor1 = 0) {this->valor1 = valor1;};

        virtual ~ClaseB(){cout<< "USANDO DESTRUCTOR CLASE B"<< endl;};
};

#endif // CLASEB_H
