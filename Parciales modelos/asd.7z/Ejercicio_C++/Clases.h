#ifndef CLASES_H
#define CLASES_H

using namespace std;

class Clases
{

    public:
        virtual ~Clases() {cout<< "Destructor Clases"<< endl;};
};

#endif // CLASES_H
