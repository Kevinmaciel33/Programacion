#ifndef CLASEA_H
#define CLASEA_H

#include "Clases.h"

class ClaseA : public Clases
{
    private:
        int valor1;

    public:
        ClaseA(int valor1 = 0) {this->valor1 = valor1;};

        virtual ~ClaseA(){cout<< "USANDO DESTRUCTOR CLASE A"<< endl;};
};

#endif // CLASEA_H
