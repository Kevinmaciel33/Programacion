
#include <iostream>

#include "ClaseA.h"
#include "ClaseB.h"

using namespace std;

int main()
{
    Clases *a = new ClaseA(2);
    Clases *b = new ClaseB(3);

    delete a;
    delete b;

    return 0;
}
