#ifndef TDALISTA_H
#define TDALISTA_H


typedef int (*Cmp)(const void* el, const void* e2);


void crearLista(Lista* pl);
int insertarEnListaOrd(Lista* pl, const void* dato, size_t tamElem, Cmp cmp);
int eliminarDeListaPrimero(Lista* pl, void* dato, size_t tamElem);
int eliminaUltimosNdeLaLista(Lista* pl, int cant);

#endif // TDALISTA_H
