#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED

#include <stdio.h>

#include "TDAListaImplDinamica.h"
#include "TDALista.h"

#define TODO_OK         0
#define ERR_ARCH        1
#define ERR_LINEA_LARGA 2
#define SIN_MEM         3
#define DUPLICADO       4

#define NOMBRE_TXT1 "cuentas.txt"
#define NOMBRE_BIN1 "resultadoCuentas.bin"

#define TAM_LIN         100


typedef struct
{
    unsigned nCuenta;
    char tipoCuenta[3];
    char ApYNm[26];
    unsigned extClave;
    float saldo;
} Cuenta;

int generarArchivos(char* nombTxt1);
int procesarArchivos(char* nombTxt1, char* nombBin1);
int trozarCampos(char* linea, Cuenta* polino);
int cmpAcc(const void* pv1, const void* pv2);

#endif // PROTOTIPOS_H_INCLUDED
