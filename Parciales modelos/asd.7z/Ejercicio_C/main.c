

#include <stdio.h>
#include <stdlib.h>

#include "Prototipos.h"

int main()
{
    int check;

    check = generarArchivos(NOMBRE_TXT1);
    if(check)
        return check;
    check = procesarArchivos(NOMBRE_TXT1, NOMBRE_BIN1);
    if(check)
        return check;

    printf("\nFIN DEL EJERCICIO");

    return 0;
}
