#include <stdlib.h>
#include <string.h>

#include "Prototipos.h"

#define min(a, b) ((a) < (b)? (a) : (b))

void crearLista(Lista* pl)
{
    *pl = NULL;
}

int insertarEnListaOrd(Lista* pl, const void* dato, size_t tamElem, Cmp cmp)
{
    while(*pl && cmp(dato, (*pl)->dato) > 0)
        pl = &(*pl)->sig;

    if(*pl && cmp(dato, (*pl)->dato) == 0)
        return DUPLICADO;

    Nodo* nue = (Nodo*)malloc(sizeof(Nodo));
    void* datoNodo = malloc(tamElem);

    if(!nue || !datoNodo)
    {
        free(nue);
        free(datoNodo);
        return SIN_MEM;
    }

    memcpy(datoNodo, dato, tamElem);
    nue->dato = datoNodo;
    nue->tamElem = tamElem;
    nue->sig = *pl;
    *pl = nue;

    return TODO_OK;
}

int eliminarDeListaPrimero(Lista* pl, void* dato, size_t tamElem)
{
    if(!*pl)
        return 0;
    Nodo* nae = *pl;
    *pl = nae->sig;

    memcpy(dato, nae->dato, min(tamElem,nae->tamElem));

    free(nae->dato);
    free(nae);

    return 1;
}
int eliminaUltimosNdeLaLista(Lista* pl, int cant)
{
    int cont = 0,
        pos;
    if(!*pl)
        return 0;

    Lista* aux = pl;

    while((*pl)->sig)
    {
        pl = &(*pl)->sig;
        cont++;
    }

    pos = cont - cant;
    while(pos != 0)
    {
        aux = &(*aux)->sig;
        pos--;
    }
    pl = aux;

    while(*aux)
    {
        Nodo* nae = *aux;
        *aux = nae->sig;
        free(nae->dato);
        free(nae);
    }

    return 1;
}
