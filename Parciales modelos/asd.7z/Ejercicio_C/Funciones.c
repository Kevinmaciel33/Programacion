#include <string.h>


#include "Prototipos.h"




int generarArchivos(char* nombTxt1)
{
    FILE* fpCuentas = fopen(nombTxt1, "wt");

    if(!fpCuentas)
    {
        printf("Error creando el archivo %s", nombTxt1);
        return ERR_ARCH;
    }

    fprintf(fpCuentas, "1111;ES;Gonzalez, Martin;123;42852.22\n2222;EN;Naranjo, Luciano;321;52852.22\n3333;EN;Mercado, Agustin;789;22852.22\n");
    fprintf(fpCuentas, "1111;ES;Ignacio, walter;123;72852.22\n5622;EN;Hernandez, Juan Miguel;857;72852.22\n3333;EN;Medina, Alejandro;789;22852.22\n");
    fclose(fpCuentas);
    return TODO_OK;
}

int procesarArchivos(char* nombTxt1, char* nombBin1)
{
    FILE* archCuen = fopen(nombTxt1, "rt");
    if(!archCuen)
        return ERR_ARCH;

    Lista listaCuenta;
    crearLista(&listaCuenta);

    Cuenta acc,
           aux;
    char linea[TAM_LIN];
    int cant,
        contador = 0;

    fgets(linea, sizeof(linea), archCuen);
    while(!feof(archCuen))
    {
        trozarCampos(linea, &acc);
        insertarEnListaOrd(&listaCuenta, &acc, sizeof(Cuenta), cmpAcc);
        fgets(linea, sizeof(linea), archCuen);
        contador++;
    }


    printf("\n\nElija cant de nodos a eliminar");
    scanf("%d",&cant);
    if(contador<cant)
        printf("\nLA CANTIDAD DE NODOS A ELIMINAR ES MAYOR A LA CANTIDAD DE NODOS DE LA LISTA\n");
    else
        eliminaUltimosNdeLaLista(&listaCuenta, cant);

    FILE* archResu = fopen(nombBin1, "wb");
    while(eliminarDeListaPrimero(&listaCuenta, &aux, sizeof(Cuenta)))
        fwrite(&aux, sizeof(Cuenta), 1, archResu);

    fclose(archCuen);
    fclose(archResu);

    return TODO_OK;
}

int trozarCampos(char* linea, Cuenta* acc)
{
    char* act = strchr(linea, '\n');

    if(!act)
        return ERR_LINEA_LARGA;
    *act = '\0';

    act = strrchr(linea, ';');
    sscanf(act+1, "%f", &acc->saldo);
    *act = '\0';

    act = strrchr(linea, ';');
    sscanf(act+1, "%u", &acc->extClave);
    *act = '\0';

    act = strrchr(linea, ';');
    strncpy(acc->ApYNm,act+1, 25);
    *act = '\0';

    act = strrchr(linea, ';');
    strncpy(acc->tipoCuenta, act+1, 2);
    *act = '\0';

    sscanf(linea, "%d", &acc->nCuenta);

    return TODO_OK;
}

int cmpAcc(const void* pv1, const void* pv2)
{
    Cuenta* acc1 = (Cuenta*)pv1;
    Cuenta* acc2 = (Cuenta*)pv2;

    if(((int)acc1->nCuenta - (int)acc2->nCuenta) == 0)
    {
        if(strcmp(acc1->tipoCuenta, acc2->tipoCuenta) == 0)
        {
            return (int)acc1->extClave - (int)acc2->extClave;
        }
        else
            return strcmp(acc1->tipoCuenta, acc2->tipoCuenta);
    }
    else
        return (int)acc1->nCuenta - (int)acc2->nCuenta;

}
