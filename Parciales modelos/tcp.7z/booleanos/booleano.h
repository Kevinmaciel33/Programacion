#ifndef BOOLEANO_H
#define BOOLEANO_H

class Booleano
{

};

#endif // BOOLEANO_H
