//#include "booleano.h"
//class Boolean
//{   //Variables
//    int value;
//
//    //Constructor
//    Boolean(int valor=0)
//    {
//        value = valor;
//    }
//    //Metodos
//    int _and(Boolean valor)
//    {
//        return value * valor.value;
//    }
//    int _or(Boolean valor)
//    {
//        if(value + valor.value>=1)
//        {
//            return 1;
//        }
//    }
//    int _not()
//    {
//        return !value;
//    }
//    string getValue()
//    {
//        if(value == 1)
//        {
//            return "true";
//        }else
//        {
//            return "False";
//        }
//    }
//};


