#ifndef BOOLEAN_H_INCLUDED
#define BOOLEAN_H_INCLUDED

class Boolean
{
private:
    int _valor;

public:
    //Boolean();
    Boolean(int = 0);

    int getValue();
};

#endif // BOOLEAN_H_INCLUDED
