
#include "Persona.h"


int main()
{
    Persona n1
    return 0;
}
