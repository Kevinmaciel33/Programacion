#include "Cuadrado.h"

Cuadrado::Cuadrado()
{
    this->color = "Ninguno";
    this->lado = 0;
}


Cuadrado::Cuadrado(const Cuadrado& otro)
{
    this->color = otro.color;
    this->lado = otro.lado;
}

void Cuadrado::setLado(double lado)
{
    this->lado = lado;
}
double Cuadrado::getLado() const
{
    return this->lado;
}

void Cuadrado::setColor(const string& color)
{
    this->color = color;
}
const string& Cuadrado::getColor() const
{
    return this->color;
}

Cuadrado& Cuadrado::operator =(float oLado)
{
    this->lado = oLado;

    return *this;
}

Cuadrado Cuadrado::operator ++(int suma)
{
    Cuadrado temp(*this);
    this->lado++;

    return temp;
}
Cuadrado& Cuadrado::operator =(const Cuadrado& otro)
{
    this->lado = otro.lado;
    this->color = otro.color;

    return *this;
}

float Cuadrado::perimetro()
{
    return this->lado*4;
}

float Cuadrado::area()
{
    return this->lado*this->lado;
}

void Cuadrado::mostrar()
{
    cout<< "Color: "<< this->color << "\nLado: "<< this->lado << endl;
}

ostream& operator <<(ostream& sal, const Cuadrado& cuad)
{
    return sal << "Color: "<< cuad.getColor() << "\nLado: "<< cuad.getLado() << endl;
}

istream& operator >>(istream& ent, Cuadrado& cuad)
{
    double lado;
    string color;

    cout << "Elegir color: ";
    ent >> color;

    cout << "Elegir lado: ";
    ent >> lado;

    cuad.setLado(lado);
    cuad.setColor(color);

    return ent;
}
