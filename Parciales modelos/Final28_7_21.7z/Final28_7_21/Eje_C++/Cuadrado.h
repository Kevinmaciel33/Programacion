#ifndef CUADRADO_H
#define CUADRADO_H

#include <iostream>
#include <string>

using namespace std;

class Cuadrado
{

    private:
        float lado;
        string color;
    public:
        Cuadrado();
        Cuadrado(const Cuadrado& otro);

        void setLado(double lado);
        double getLado() const;
        void setColor(const string& color);
        const string& getColor() const;

        Cuadrado& operator =(float oLado);
        Cuadrado operator ++(int suma);
        Cuadrado& operator =(const Cuadrado& otro);

        float perimetro();
        float area();

        void mostrar();

        friend ostream& operator <<(ostream& sal, const Cuadrado& cuad);
        friend istream& operator >>(istream& ent, Cuadrado& cuad);

};

#endif // CUADRADO_H
