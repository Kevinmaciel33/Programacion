#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdio.h>

#include "TDAListaImplDinamica.h"
#include "TDALista.h"

#define TODO_OK         0
#define ERR_ARCH        1
#define ERR_LINEA_LARGA 2
#define SIN_MEM         3

#define TAM_LIN         100

#define NOMBRE_TXT1 "p1.txt"
#define NOMBRE_TXT2 "p2.txt"
#define NOMBRE_TXT3 "pr.txt"


typedef struct
{
    int poten;
    int coef;
}Polinomio;


int generarArchivos(const char* nombTxt1, const char* nombTxt2);
int procesarArchivos(const char* nombTxt1, const char* nombTxt2, const char* nombTxt3);
void rellenarLista(FILE* arch, Lista* listaPols);
int trozarCampos(char* linea, Polinomio* polino);


#endif // MAIN_H_INCLUDED
