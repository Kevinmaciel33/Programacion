#include <string.h>

#include "main.h"

int cmpPol(const void* pv1, const void* pv2);
void actuaPol(void* pvpActualizado, const void* pvpActualizador);

int generarArchivos(const char* nombTxt1, const char* nombTxt2)
{
    FILE* fpP1 = fopen(nombTxt1, "wt");

    if(!fpP1)
    {
        printf("Error creando el archivo %s", nombTxt1);
        return ERR_ARCH;
    }

    fprintf(fpP1, "X(2)(4)\nX(5)(3)\nX(-2)(-5)\nX(2)(2)\nX(1)(0)\n");
    fclose(fpP1);

    FILE* fpP2 = fopen(nombTxt2, "wt");

    if(!fpP2)
    {
        printf("Error creando el archivo %s", nombTxt2);
        return ERR_ARCH;
    }

    fprintf(fpP2, "X(1)(0)\nX(5)(-3)\nX(-2)(6)\nX(2)(2)\nX(7)(4)\n");
    fclose(fpP2);

    return TODO_OK;
}

int procesarArchivos(const char* nombTxt1, const char* nombTxt2, const char* nombTxt3)
{
    FILE* archP1 = fopen(nombTxt1, "rt");
    FILE* archP2 = fopen(nombTxt2, "rt");
    FILE* archPr = fopen(nombTxt3, "wt");

    if(!archP1 || !archP2 || !archPr)
        return ERR_ARCH;

    Lista listaPols;
    crearLista(&listaPols);

    rellenarLista(archP1, &listaPols);
    rellenarLista(archP2, &listaPols);

    Polinomio pol;
    while(eliminarDeListaPrimero(&listaPols, &pol, sizeof(Polinomio)))
    {
        if(pol.coef != 0)
            fprintf(archPr,"X(%d)(%d) ", pol.poten, pol.coef);
    }

    return TODO_OK;
}

void rellenarLista(FILE* archP1, Lista* listaPols)
{
    Polinomio polino;
    char linea[TAM_LIN];

    fgets(linea, sizeof(linea), archP1);
    while(!feof(archP1))
    {
        trozarCampos(linea, &polino);
        insertarOActualizarEnListaOrd(listaPols, &polino, sizeof(Polinomio), cmpPol, actuaPol);
        fgets(linea, sizeof(linea), archP1);
    }
}

int trozarCampos(char* linea, Polinomio* polino)
{
    char* act = strchr(linea, '\n');

    if(!act)
        return ERR_LINEA_LARGA;
    *act = '\0';

    act = strrchr(linea, '(');
    sscanf(act+1, "%d", &polino->coef);

    act--;
    *act = '\0';

    act = strrchr(linea, '(');
    sscanf(act+1, "%d", &polino->poten);


    return TODO_OK;
}

int cmpPol(const void* pv1, const void* pv2)
{
    Polinomio* pol1 = (Polinomio*)pv1;
    Polinomio* pol2 = (Polinomio*)pv2;

    return pol1->poten - pol2->poten;

}

void actuaPol(void* pvpActualizado, const void* pvpActualizador)
{
    Polinomio* prodActualizado = (Polinomio*)pvpActualizado;
    Polinomio* prodActualizador = (Polinomio*)pvpActualizador;

    prodActualizado->coef += prodActualizador->coef;
}

