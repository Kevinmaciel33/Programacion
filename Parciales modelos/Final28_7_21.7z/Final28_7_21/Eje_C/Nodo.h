#ifndef NODO_H
#define NODO_H

#include <stddef.h>

typedef struct sNodo
{
    void* dato;
    size_t tamElem;
    struct sNodo* sig;
}
Nodo;

#endif // NODO_H
