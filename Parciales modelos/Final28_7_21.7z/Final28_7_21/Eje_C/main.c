#include "main.h"

int main()
{
    int check;
    check = generarArchivos(NOMBRE_TXT1, NOMBRE_TXT2);
    if(check)
        return check;
    check = procesarArchivos(NOMBRE_TXT1, NOMBRE_TXT2, NOMBRE_TXT3);
    if(check)
        return check;

    printf("\n\nFINALIZO\n\n");

    return TODO_OK;
}
