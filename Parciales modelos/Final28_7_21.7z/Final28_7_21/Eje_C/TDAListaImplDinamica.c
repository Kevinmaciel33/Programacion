#include <stdlib.h>
#include <string.h>

#include "main.h"

#define min(a, b) ((a) < (b)? (a) : (b))


void crearLista(Lista* pl)
{
    *pl = NULL;
}

int insertarOActualizarEnListaOrd(Lista* pl, const void* dato, size_t tamElem, Cmp cmp, Actualizar actualizar)
{
    while(*pl && cmp(dato, (*pl)->dato) > 0)
        pl = &(*pl)->sig;

    if(*pl && cmp(dato, (*pl)->dato) == 0)
    {
        actualizar((*pl)->dato, dato);
        return TODO_OK;
    }



    Nodo* nue = (Nodo*)malloc(sizeof(Nodo));
    void* datoNodo = malloc(tamElem);

    if(!nue || !datoNodo)
    {
        free(nue);
        free(datoNodo);
        return SIN_MEM;
    }

    memcpy(datoNodo, dato, tamElem);
    nue->dato = datoNodo;
    nue->tamElem = tamElem;
    nue->sig = *pl;
    *pl = nue;

    return TODO_OK;
}

int eliminarDeListaPrimero(Lista* pl, void* dato, size_t tamElem)
{
    if(!*pl)
        return 0;
    Nodo* nae = *pl;
    *pl = nae->sig;

    memcpy(dato, nae->dato, min(tamElem,nae->tamElem));

    free(nae->dato);
    free(nae);

    return 1;
}
