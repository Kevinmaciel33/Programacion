#ifndef TDALISTA_H
#define TDALISTA_H


typedef int (*Cmp)(const void* el, const void* e2);

typedef void (*Actualizar)(void* actualizado, const void* actualizador);

void crearLista(Lista* pl);
int insertarOActualizarEnListaOrd(Lista* pl, const void* dato, size_t tamElem, Cmp cmp, Actualizar actualizar);
int eliminarDeListaPrimero(Lista* pl, void* dato, size_t tamElem);


#endif // TDALISTA_H
