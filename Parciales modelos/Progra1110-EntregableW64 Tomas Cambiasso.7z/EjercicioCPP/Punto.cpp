#include <math.h>
#include "Punto.h"


Punto::Punto(double x, double y): x(x), y(y)
{}

ostream& operator <<(ostream& sal, const Punto p1)
{
    return sal <<'('<< p1.x << ','<<p1.y<<')';

}

