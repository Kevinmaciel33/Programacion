#include "RectaException.h"


