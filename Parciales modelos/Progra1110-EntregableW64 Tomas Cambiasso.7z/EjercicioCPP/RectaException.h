#ifndef RECTAEXCEPTION_H
#define RECTAEXCEPTION_H

#include <string>

using namespace std;





#endif // RECTAEXCEPTION_H
