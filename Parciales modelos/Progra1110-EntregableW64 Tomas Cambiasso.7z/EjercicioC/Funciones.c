#include <stdio.h>
#include <stdlib.h>
#include "tipos.h"
#include "Funciones.h"
#include <string.h>



void crearLista(tLista* lista)
{
    *lista=NULL;
}

int crearLotePrueba(const char* filename)
{
    int i;
    FILE* fp=fopen(filename,"wt");
    tentradaSalida movs[]=
    {
        {1625766103,"GKM925",'E','A',},
        {1625766704,"KAL663",'E','B'},
        {1625767305,"MNJ996",'E','A'},
        {1625767906,"MNJ996",'S','A'},
        {1625768507,"KAL663",'S','B'}

    };
    if(!fp)
    {
        return 0;
    }

    for (i=0; i<sizeof(movs)/sizeof(tentradaSalida) ; i++ )
    {

        fprintf(fp,"%12ld%10s%1c%1c\n",movs[i].timestamp,movs[i].dominio,movs[i].tipo,movs[i].sector);
    }


    fclose(fp);

    return 1;
}

int desglozamiento (char * cad, tentradaSalida * mov) //asumo que el archivo viene validado, (sin espacios)
{

    cad+=(strlen(cad)-1);
    mov->sector=*cad;
    *cad='\0';
    cad-=1;
    mov->tipo=*cad;
    *cad='\0';
    cad-=10;
    strcpy(mov->dominio,cad);
    *cad='\0';
    cad-=12;
    sscanf(cad,"%10ld",&(mov->timestamp));

    return 1;
}

int insertarAlFinalR(tLista* lista, void* dato, unsigned tam)
{
    tNodo* nuevo;

    if(*lista)
    {
        insertarAlFinalR(&(*lista)->sig,dato,tam);

    }
    else
    {
        nuevo=malloc(sizeof(tNodo));

        if(!nuevo)
        {
            return 0;
        }
        nuevo->info=malloc(tam);

        if(!(nuevo->info))
        {
            free(nuevo);
            return 0;
        }
        memcpy(nuevo->info,dato,tam);
        nuevo->tam=tam;
        nuevo->sig=*lista;
        *lista=nuevo;
    }
    return 1;
}
int recorrerLista(tLista* lista, char* veh, int ini,int fin)
{
    if(ini>fin)
    {
        return 0;
    }
    if(!strcmp(veh,(*lista)->info))
{
    return 1;
}
else
{
    return recorrerLista(lista,veh,ini+1,fin);
}
}
int entro(tLista* lista,char* veh,char sector, const tsector* secs)
{
    int i=0,indice=0,fin;
    fin=sizeof(secs)/sizeof(tsector);
    while(sector!=secs[i].code)
    {
        i++;
    }
    for (i=i; i<0 ; i-- )
    {
        indice+=secs[i].cantMuelles;
    }

    return recorrerLista(lista,veh,indice,fin-1);
}

int hayespacio(tLista* lista, char* cad)
{

}

int generarInforme(const char* filename, const char* output, const tsector* secs)
{
    int i;
    char linea[25];
    tLista lista;
    tentradaSalida tempMov;
    FILE* pLote=fopen(filename,"rt");

    crearLista(&lista);

    for (i=0; i<sizeof(secs)/sizeof(tsector) ; i++ )
    {
        insertarAlFinalR(&lista,"",sizeof(tempMov.dominio));
    }

    if(!pLote)
    {
        return 0;
    }


    while(fgets(linea,25,pLote))
    {
        desglozamiento(linea,&tempMov);

        if(!entro(&lista,tempMov.dominio,tempMov.sector, secs))
        {
           // if(hayespacio())
        }

    }

}
