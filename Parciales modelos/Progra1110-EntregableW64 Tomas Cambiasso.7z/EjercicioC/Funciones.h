#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct Snodo{

void* info;
unsigned tam;
struct Snodo* sig;
}tNodo;

typedef tNodo* tLista;


#endif // FUNCIONES_H_INCLUDED
